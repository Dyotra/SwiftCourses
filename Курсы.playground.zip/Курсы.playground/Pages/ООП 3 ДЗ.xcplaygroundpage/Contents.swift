class Employee {
    let name: String
    let salary: Double
    init(name: String, salary: Double) {
        self.name = name
        self.salary = salary
    }
}
class Manager: Employee {
    var bonus: Double
    init(name: String, salary: Double, bonus: Double) {
        self.bonus = bonus
        super.init(name: name, salary: salary)
    }
}
class Developer: Employee {
    let programmingLanguage: String
    init(name: String, salary: Double, programmingLanguage: String) {
        self.programmingLanguage = programmingLanguage
        super.init(name: name, salary: salary)
    }
}
class Designer: Employee {
    let designSoftware: String
    init(name: String, salary: Double, designSoftware: String) {
        self.designSoftware = designSoftware
        super.init(name: name, salary: salary)
    }
}
class Department {
    let name: String
    var employees: [Employee]
    init(name: String, employees: [Employee]) {
        self.name = name
        self.employees = employees
    }
    func hireEmployee(_ employee: Employee) {
        employees.append(employee)
    }
    func fireEmployee(_ employee: Employee) {
        if let index = employees.firstIndex(where: { $0.name == employee.name }) {
            employees.remove(at: index)
            print("Работник \(employee.name) был уволен из штаба департамента \(name).")
        } else {
            print("Работник \(employee.name) не найден в департаменте \(name).")
        }
    }
    func totalSalary() -> Double {
        var total = 0.0
        for employee in employees {
            total += employee.salary
        }
        return total
    }
}
let manager = Manager(name: "John Appleseed", salary: 1000000.0, bonus: 10000.0)
let developer = Developer(name: "Dana White", salary: 2000000.0, programmingLanguage: "Swift")
let designer = Designer(name: "Bob Ross", salary: 1500000.0, designSoftware: "Photoshop")
let department = Department(name: "IT", employees: [manager, developer])
department.fireEmployee(designer)
department.hireEmployee(Developer(name: "Dias", salary: 1000000, programmingLanguage: "Swift"))
print("Список сотрудников в отделе:")
for employee in department.employees {
    print("Имя: \(employee.name)")
    if let manager = employee as? Manager {
        print("Должность: Менеджер")
        print("Зарплата: \(manager.salary)")
        print("Бонус: \(manager.bonus)")
    } else if let developer = employee as? Developer {
        print("Должность: Разработчик")
        print("Зарплата: \(developer.salary)")
        print("Язык программирования: \(developer.programmingLanguage)")
    } else if let designer = employee as? Designer {
        print("Должность: Дизайнер")
        print("Зарплата: \(designer.salary)")
        print("Программа для дизайна: \(designer.designSoftware)")
    }
}
print("Общая зарплата всех сотрудников департамента: \(department.totalSalary())")
