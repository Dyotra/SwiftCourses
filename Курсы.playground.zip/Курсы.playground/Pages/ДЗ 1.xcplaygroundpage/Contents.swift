import Darwin
let a = 2
let b = 5
let area = a * b / 2
let c = sqrt(Double(a * a + b * b))
let perimetr = Double(a + b) + c
print("Ваша площадь = \(area)!")
print("Ваша гипотенуза = \(c)!")
print("Ваш периметр = \(perimetr)!")
