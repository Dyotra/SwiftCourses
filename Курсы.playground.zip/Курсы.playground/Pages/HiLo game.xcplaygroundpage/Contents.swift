struct Card:Equatable {
    var suit: String
    var rank: String
}
struct Deck {
    var suits: [String] = ["♥️", "♦️", "♣️", "♠️"]
    var ranks: [String] = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    var cards: [Card] = []
    init () {
        for suit in suits {
            for rank in ranks {
                let card = Card(suit: suit, rank: rank)
                cards.append(card)
            }
        }
    }
    mutating func shuffle() {
        cards.shuffle()
    }
    func openCard() {
        
    }
}
