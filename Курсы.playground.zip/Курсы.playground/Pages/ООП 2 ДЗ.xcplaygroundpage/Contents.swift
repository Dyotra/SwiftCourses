class Vehicle {
    var make: String
    var yearOfProduction: Int
    var model: String
    init(make: String, yearOfProduction: Int, model: String) {
        self.make = make
        self.yearOfProduction = yearOfProduction
        self.model = model
    }
    func isNewOrOld() {
        if yearOfProduction >= 2010 { print ("Относительно новое транспортное средство") }
        else { print ("Относительно старое транспортное средство") }
    }
    func name() {
        print("Транспортное средство марки \(make), модели \(model), \(yearOfProduction) года производства")
    }
}
class Bike: Vehicle {
    override func isNewOrOld() {
        if yearOfProduction >= 2017 { print ("Относительно новый велосипед") }
        else { print ("Относительно старый велосипед") }
    }
    override func name() {
        print("Велосипед марки \(make), модели \(model), \(yearOfProduction) года производства")
    }
}
class Car: Vehicle {
    var engineCapacity: Double
    init(engineCapacity: Double, make: String, yearOfProduction: Int, model: String) {
        self.engineCapacity = engineCapacity
        super.init(make: make, yearOfProduction: yearOfProduction, model: model)
    }
    override func name() {
        print("Автомобиль марки \(make), модели \(model), \(yearOfProduction) года производства")
    }
    func motorTax() {
        if engineCapacity < 1500 {
            print("Налог на объем двигателя составляет 1 МРП")
        }
        else if engineCapacity >= 1500 && engineCapacity < 2000 {
            print("Налог на объем двигателя составляет 2 МРП")
        }
        else if engineCapacity >= 2000 && engineCapacity < 2500 {
            print("Налог на объем двигателя составляет 3 МРП")
        }
        else if engineCapacity >= 2500 && engineCapacity < 3000 {
            print("Налог на объем двигателя составляет 9 МРП")
        }
        else if engineCapacity >= 3000 && engineCapacity < 4000 {
            print("Налог на объем двигателя составляет 15 МРП")
        }
        else { print("Налог на объем двигателя составляет 117 МРП") }
    }
    override func isNewOrOld() {
        if yearOfProduction >= 2010 { print ("Относительно новая машина") }
        else { print ("Относительно старая машина") }
    }
}
let bike1 = Bike(make: "Trek bicycle", yearOfProduction: 2020, model: "X-Caliber")
let bike2 = Bike(make: "AIST", yearOfProduction: 1989, model: "111-331")
let car1 = Car(engineCapacity: 1.8, make: "Chevrolet", yearOfProduction: 2014, model: "Tracker")
let car2 = Car(engineCapacity: 2.4, make: "Toyota", yearOfProduction: 2002, model: "Camry 30")
bike1.name()
bike2.isNewOrOld()
car1.motorTax()
car2.isNewOrOld()
