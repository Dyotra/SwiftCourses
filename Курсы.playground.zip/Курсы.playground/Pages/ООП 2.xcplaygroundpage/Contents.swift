class Animal {
   let name: String
   private(set) var isHungry: Bool
   init(name: String, isHungry: Bool = true) {
       self.name = name
       self.isHungry = isHungry
   }
   func eat() {
       isHungry = false
   }
}
class Tiger: Animal {
   let foodRequired = 10
   private var foodConsumed = 0
   override func eat() {
       eat(amountOfFood: foodRequired)
   }
   func eat(amountOfFood: Int) {
       foodConsumed += amountOfFood
       guard foodConsumed >= foodRequired else { return }
       super.eat()
   }
   func amIHungry() {
       print("🐯 I am " + (isHungry ? "seriously hungry..." : "not really hungry right now."))
   }
}
let tiger = Tiger(name: "Felix")
tiger.eat(amountOfFood: 10)
tiger.amIHungry()

// practical
class Deer: Animal {
   let grossRequired = 20
   private var grossConsumed = 0
   override func eat() {
       eat(amountOfGross: grossRequired)
   }
   func eat(amountOfGross: Int) {
       grossConsumed += amountOfGross
       guard grossConsumed >= grossRequired else { return }
       super.eat()
   }
   func amIHungry() {
       print("🦌 I am " + (isHungry ? "seriously hungry..." : "not really hungry right now."))
   }
}
let deer = Deer(name: "Bembi")
deer.eat(amountOfGross: 15)
deer.amIHungry()
