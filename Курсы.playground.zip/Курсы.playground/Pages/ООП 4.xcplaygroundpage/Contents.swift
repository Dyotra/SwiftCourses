protocol Speakable {
    func speak() 
}
struct Cow: Speakable {
    func speak() {
        print("Muu")
    }
}
struct Dog: Speakable {
    func speak() {
        print("Gaf Gaf")
    }
}
let cow = Cow()
cow.speak
