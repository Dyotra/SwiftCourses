// 1-2 практическаяя
import Foundation
enum Gender {
 case male
 case female
 case notspecified
}
let user: (userName: String, email: String, isActive: Bool, phoneNo: Int?, address: String?, gender: Gender)
    
user = (userName: "Dias", email: "asd@gmail.com", isActive: true, phoneNo: 87777777777, address: nil, gender: .male)
    
    print (user.userName)
    print (user.email)
    print (user.isActive)
    print (user.phoneNo ?? "No number")
    print (user.address ?? "No address")
    print (user.gender)



