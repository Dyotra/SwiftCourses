import Foundation
protocol Matrix {
    associatedtype Element
    var elements: [[Element]] { get set }
    var row: Int { get set }
    var column: Int { get set }
    func getValue(row: Int, column: Int) -> Element?
    mutating func setValue(row: Int, column: Int, value: Element)
    subscript(row: Int, column: Int) -> Element? { get set }
}
struct MyStruct<Element>: Matrix {
    var elements: [[Element]]
    var row: Int
    var column: Int
    func getValue(row: Int, column: Int) -> Element? {
        guard row >= 0 && row < elements.count && column >= 0 && column < elements[row].count else {
            fatalError("Index out of range")
        }
        return elements[row][column]
    }
    mutating func setValue(row: Int, column: Int, value: Element) {
        guard row >= 0 && row < elements.count && column >= 0 && column < elements[row].count else {
            fatalError("Index out of range")
        }
        elements[row][column] = value
    }
    subscript(row: Int, column: Int) -> Element? {
        get {
            return getValue(row: row, column: column)
        }
        set {
            if let newValue = newValue {
                setValue(row: row, column: column, value: newValue)
            } else {
                fatalError("Index out of range")
            }
        }
    }
}
var matrix = MyStruct(elements: [["Dias", "Gafur"], ["Milana","Olzhas"]], row: 2, column: 2)
print(matrix.getValue(row: 1, column: 1))

