// 1 практическая
func average(_ arr: [Int]) -> Double {
    var sum = 0
    for i in arr {
        sum += i
    }
    return Double(sum) / Double(arr.count)
}
print(average([1,2,3,4,5,5,6]))
// 2 парктическая
func intersect(_ a: [Int], _ b: [Int]) -> Set<Int> {
    var set1 = 0
    var set2 = 0
    return set1.intersection(set2)
}
print(intersect([1, 2, 3], [3, 4]))
