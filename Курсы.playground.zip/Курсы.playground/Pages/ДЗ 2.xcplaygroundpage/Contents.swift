var s : Double = 10000
print ("Ваша сумма вклада составляет \(s)")
let p : Double = 0.14
s += p * s
s += p * s
s += p * s
s += p * s
s += p * s
print ()
print ("Через 5 лет ваша сумма будет составлять \(s)")
