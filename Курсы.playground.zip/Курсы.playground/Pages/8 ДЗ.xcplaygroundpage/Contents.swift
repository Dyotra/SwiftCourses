//1 func
var students = ["Ivan": 4, "Aset": 5, "Mihail": 3, "Alexey": 3]
func student3Grade(grades: [String: Int]) -> [String: Int] {
    let badGrades = grades.filter{ (key: String, value: Int)  -> Bool in value < 4 }
    return badGrades
}
print(student3Grade(grades: students))
//2 func
func addStudent(_ name: String, _ grade: Int){
    students.updateValue(grade, forKey: name)
}
addStudent("Mary", 4)
print(students)
// 3 func
func newGrade(name: String, newGrade: Int) {
    if let grade = students.updateValue(newGrade, forKey: name) {
        print("Оценка студента \(name) изменена с \(grade) на \(newGrade)")
    } else {
        print("Студент не найден")
    }
}
newGrade(name: "Aset", newGrade: 3)
print(students)

func getDateOfBirthAndSexFrom(iin: String) -> (String? , String?) {
    let stringArray = Array(iin)
    
    guard let facet = Int(String(stringArray[6])) else {
        return (nil, nil)
    }
    
    var sex: String?
    var year: String?
    
    switch facet {
    case 1, 2:
        year = "18"
        sex = facet == 1 ? "Муж" : "Жен"
        print("Мужчина, 19 век")
    case 3, 4:
        year = "19"
        sex = facet == 3 ? "Муж" : "Жен"
    case 5, 6:
        year = "20"
        sex = facet == 5 ? "Муж" : "Жен"
    default:
        return (nil, nil)
    }
    
    let day = String(stringArray[4]) + String(stringArray[5])
    let month = String(stringArray[2]) + String(stringArray[3])
    year? += String(stringArray[0]) + String(stringArray[1])
    
    return (year, sex)
}

let result = getDateOfBirthAndSexFrom(iin: "850120399018")

if let year = result.0 {
    print("Год рождения: \(year)")
}

if let sex = result.1 {
    print("Пол: \(sex)")
}
