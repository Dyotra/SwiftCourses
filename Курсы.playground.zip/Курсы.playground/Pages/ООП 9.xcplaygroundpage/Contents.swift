func performOperation(_ leftOperand: Double, _ rightOperand: Double, _ operation: (Double, Double) -> Double) {
    let result = operation(leftOperand, rightOperand)
    print("Результат операции: \(result)")
}

performOperation(4, 3) { a, b in
    return a + b
}
