class Person {
    var name: String
    var age: Int
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    func greet() {
        print("Приветствую \(name), Ваш возраст - \(age)")
    }
    func celebrateBirthday() {
        age += 1
        print("Поздравляю! Вам исполнилось \(age)")
    }
}
let person = Person(name: "Диас", age: 23)
person.greet()
print()
person.celebrateBirthday()
