class Car {
    let yearOfProduction: Int
    let mark: String
    let model: String
    init(yearOfProduction: Int, mark: String, model: String) {
        self.yearOfProduction = yearOfProduction
        self.mark = mark
        self.model = model
    }
    func newOrOld(_ yearOfProoduction: Int) -> Bool {
        return yearOfProoduction >= 2010
    }
}
let car1 = Car(yearOfProduction: 2014, mark: "Chevrolet", model: "Tracker")
car1.newOrOld(2005)
