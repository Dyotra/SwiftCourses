for x in 2...100 {
    var prime = true
    for i in 2..<x {
        if x % i == 0 {
            prime = false
            break
        }
    }
if prime {
    print(x)
    }
}

