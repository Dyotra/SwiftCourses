protocol MyCustomStringConvertible {
    var description: String { get }
}
struct MyStruct: MyCustomStringConvertible {
    var a: Int
    var b: Int
    var description: String {
        return "\(a), \(b)"
    }
}
let c = MyStruct(a: 3, b: 4)
print(c.description)
