import Foundation

let currency = 450

var mprice = 2399 * currency

let wprice = 450 * currency

let formatter = NumberFormatter()
formatter.numberStyle = .currency

let formattedmPrice = formatter.string(from: NSNumber(value: mprice))

    print("стоимость MacBook - ", formattedmPrice ?? "неправильно введена сумма")

let formattedwPrice = formatter.string(from: NSNumber(value: wprice))

    print("стоимость MacBook - ", formattedwPrice ?? "неправильно введена сумма")
