print ("Hello, world! ")

