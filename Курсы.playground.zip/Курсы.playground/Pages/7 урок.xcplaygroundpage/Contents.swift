import Foundation
// 1 задание
func isEven (_ n: Int) -> Bool { n % 2 == 0 }
print(isEven(5))

// 2 задание
func calculateArea (_ a: Int, _ b: Int) -> Int { a * b }
func calculateArea(_ r: Double) -> Double { .pi * r * r }
print(calculateArea(6))
print(calculateArea(6, 3))
