protocol Animal {
    var name: String {get set}
    var makeSound: String {get set}
    var type: String {get set}
    func info()
    func voice()
}
protocol Walkable {
    func walk()
}
protocol Swimmable {
    func swim()
}
protocol Flyable {
    func fly() 
}
struct Dog: Animal, Walkable {
    var name: String
    var makeSound: String
    var type: String
    func info() {
        print("Animal name is \(name), type - \(type)")
    }
    func voice() {
        print("This animal is making '\(makeSound)' sound")
    }
    func walk() {
        print("This animal walks")
    }
}
struct Raven: Animal, Flyable {
    var name: String
    var makeSound: String
    var type: String
    func info() {
        print("Animal name is \(name), type - \(type)")
    }
    func voice() {
        print("This animal is making '\(makeSound)' sound")
    }
    func fly() {
        print("This animal flies")
    }
}
struct Dolphin: Animal, Swimmable {
    var name: String
    var makeSound: String
    var type: String
    func info() {
        print("Animal name is \(name), type - \(type)")
    }
    func voice() {
        print("This animal is making '\(makeSound)' sound")
    }
    func swim() {
        print("This animal swims")
    }
}
let dog = Dog(name: "Muhtar", makeSound: "Gaf Gaf", type: "mammal")
let raven = Raven(name: "Voron", makeSound: "Kar Kar", type: "bird")
let dolphin = Dolphin(name: "Smarty", makeSound: "Krrrrrrr", type: "mammal")
dog.info()
dog.voice()
dog.walk()
dolphin.voice()
