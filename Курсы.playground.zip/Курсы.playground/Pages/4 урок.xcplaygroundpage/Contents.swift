let n = 5
    
    if n % 2 == 0 {
        print ("число четное")
    }
    else {
        print ("число нечетное")
    }


let num = 6
    
    switch n % 2 {
    case 0:
        print ("число четное")
    default:
        print ("число нечетное")
    }

let number = 7
print (number % 2 == 0 ? "четное" : "нечетное")
