// 1 задание
var n: Int
for i in 2...9 {
    for j in 1...10 {
        n = i * j
        print ("\(i) * \(j) = \(n)")
    }
}
// 2 задание
var number: Int?
print("Введите число:", terminator: "")
number = Int(readLine() ?? "Неправильно введено число")
if let number = number {
    if number % 3 == 0 && number % 5 == 0 {
        print("FizzBuzz")
    } else if number % 3 == 0 {
        print("Fizz")
    } else if number % 5 == 0 {
        print("Buzz")
    } else {
        print(number)
    }
}
// 3 задание
for x in 2...100 {
    var prime = true
    for i in 2..<x {
        if x % i == 0 {
            prime = false
            break
        }
    }
if prime {
    print(x)
    }
}

