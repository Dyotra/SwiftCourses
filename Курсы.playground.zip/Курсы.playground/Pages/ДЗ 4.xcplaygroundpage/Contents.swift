import Foundation
let a : Float = 2.2
let b : Float = 5.3
let c : Float = 2.3
    print ("Ваше уравнение имеет вид : \(a)x^2 + \(b)x + \(c) = 0")
    let d = b * b - 4 * a * c
    if d < 0 {
        print ("Дискриминант < 0, корней нет:")
    }
else if d == 0 {
    print ("Дискриминант = 0, у решения один корень:")
    let x = -b / 2 * a
    print(String(format: "X = %.1f", x))
    }
    else {
        print ("Дискриминант > 0, у решения 2 корня:")
        let x1 = ( -b + sqrt(d)) / 2 * a
        let x2 = ( -b - sqrt(d)) / 2 * a
        print(String(format: "X1 = %.1f", x1))
        print(String(format: "X2 = %.1f", x2))
    }
