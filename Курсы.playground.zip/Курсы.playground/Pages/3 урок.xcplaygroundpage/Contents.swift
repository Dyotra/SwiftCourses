let text = "745"
let number  = Int(text)
if let number = number {
    print (number)
}
else {
    print ("не правильно указано значение")
}

// Проверка на nil, Милана
if number != nil {
    print (number!)
}

// If-let, Илья
if  let number = number {
    print(number)
}

// nil-коалесцирующий, Акерке
print(number ?? 0)

// force-unwrap
print(number!)
// Форматирование
print(String(format: "price: %f euro.", 2.99))
