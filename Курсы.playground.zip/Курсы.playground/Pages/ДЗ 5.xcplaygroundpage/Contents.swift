import Foundation
enum SmartBulb {
    case on
    case off
    case brighter
    case dimmer
}
enum SmartLock {
    case on
    case off
}
enum SmartJalousie {
    case open
    case closed
}
var bulb: SmartBulb = .brighter
    switch bulb {
    case .on:
        print ("Включить")
    case .off:
        print ("Выключить")
    case .brighter:
        print ("Сделать ярче")
    case .dimmer:
        print ("Сделать тусклее")
}
var lock: SmartLock = .off
    switch lock {
    case .on:
    print ("Открыть замок")
    case .off:
    print ("Закрыть замок")
}
var jalousie: SmartJalousie = .open
    switch jalousie {
    case .open:
    print ("Открыть жалюзи")
    case .closed:
    print ("Закрыть жалюзи")
}
