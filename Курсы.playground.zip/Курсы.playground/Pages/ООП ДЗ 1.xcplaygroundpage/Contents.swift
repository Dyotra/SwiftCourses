class Card {
    let mast: String
    let rank: String
    init(mast: String, rank: String) {
        self.mast = mast
        self.rank = rank
    }
}
class Deck {
    var cards = [Card]()
    init() {
        let masti = ["♥️", "♦️", "♣️", "♠️"]
        let ranks = ["6", "7", "8", "9", "10", "J", "Q", "K", "A"]
        for mast in masti {
            for rank in ranks {
                let card = Card(mast: mast, rank: rank)
                cards.append(card)
            }
        }
    }
    func shuffle() {
        cards.shuffle()
    }
    func openCards() -> [Card]? {
        var openCard = [Card]()
        let card = cards.removeLast()
        openCard.append(card)
        return openCard
    }
}
enum HL: String {
    case higher = "H"
    case lower = "L"
}


