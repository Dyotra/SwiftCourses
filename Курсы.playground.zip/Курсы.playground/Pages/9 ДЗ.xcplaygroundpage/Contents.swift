// 1 задание
class Car {
    var mark: String
    var model: String
    var year: Int
    init (mark: String,model: String,year: Int) {
        self.mark = mark
        self.model = model
        self.year = year 
    }
    func description() {
        print("Марка вашей машины - \(mark), модель - \(model) и год выпуска - \(year)")
    }
}
let myCar = Car(mark: "Toyota", model: "Camry", year: 2017)
myCar.description()
// 2 задание
struct TemperatureConverter {
    var celsius: Double
    func conversion() {
        let farenheit = celsius * 1.8 + 32
        print("Ваша температура \(celsius)ºC в фаренгейтах будет равна - \(farenheit)F")
    }
}
var myTemperature = TemperatureConverter(celsius: 10)
myTemperature.conversion()
