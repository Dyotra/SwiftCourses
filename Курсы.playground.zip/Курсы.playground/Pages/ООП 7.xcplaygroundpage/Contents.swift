/*func elementsOfArray<T>(_ array: [T]) {
    for element in array {
        print(element)
    }
}
let array1 = [23,23,34,55]
elementsOfArray(array1)
let array2 = [23.2,24.2,34.2,55.2]
elementsOfArray(array2) */
struct Stack<T> {
    var items: [T] = []
    mutating func push(_ item: T) {
        items.append(item)
    }
    mutating func pop() -> T? {
        items.popLast()
    }
    mutating func peek() -> T? {
        items.last
    }
    var count: Int {
        items.count
    }
    var isEmpty: Bool {
        items.isEmpty
    }
}
var stack1 = Stack<Int>()
stack1.push(4)
stack1.push(3)
stack1.push(2)
print(stack1.items)
var stack2 = Stack<String>()
stack2.push("asd")
stack2.push("ads")
stack2.push("123")
print(stack2.items)

