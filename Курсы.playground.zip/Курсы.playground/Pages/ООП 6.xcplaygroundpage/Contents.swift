protocol Stackable {
    var items: [any Numeric] { get }
    mutating func push(_ item: any Numeric)
    mutating func pop() -> (any Numeric)?
    mutating func peek() -> (any Numeric)?
}
extension Stackable {
    var count: Int {
        items.count
    }
    var isEmpty: Bool {
        items.isEmpty
    }
}
struct Stack: Stackable {
    var items: [any Numeric] = []
    mutating func push(_ item: any Numeric) {
        items.append(item)
    }
    mutating func pop() -> (any Numeric)? {
        items.popLast()
    }
    mutating func peek() -> (any Numeric)? {
        items.last
    }
}
var stack = Stack()
stack.push(4)
stack.push(3)
stack.push(2)
print(stack.items)

