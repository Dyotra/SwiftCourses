import Foundation
enum EquationError: Error {
    case aZero
    case discriminantNegative
}
func solveQuadraticEquation(a: Double, b: Double, c: Double) throws -> (Double, Double) {
    guard a != 0 else {
        throw EquationError.aZero
    }
    let discriminant = b * b - 4 * a * c
    guard discriminant >= 0 else {
        throw EquationError.discriminantNegative
    }
    let x1 = (-b + sqrt(discriminant)) / (2 * a)
    let x2 = (-b - sqrt(discriminant)) / (2 * a)
    return (x1, x2)
}
do { let result = try solveQuadraticEquation(a: 5, b: 2, c: -5)
    print(result)
}
    catch EquationError.aZero {
    print("Ошибка: a не может быть равно 0.")
}   catch EquationError.discriminantNegative {
    print("Ошибка: дискриминант < 0.")
}
