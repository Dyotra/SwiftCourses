import Foundation
// 1 задание
func power(_ base: Double, _ exponent: Double) -> Double { pow(base, exponent) }
print(power(5,2))

// 2 задание
func sumOfIntegers(_ n: Int) -> Int {
    if n < 1 {
        print ("Error")
        return 0
    }
    else {
        var sum = 0
        for i in 1..<n {
            sum += i }
        return sum } }
print(sumOfIntegers(15))

// 3 задание
func isPrime(_ n: Int) -> Bool {
    guard n > 1 else {
        return false
    }
    for i in 2..<n {
        if n % i == 0 {
            return false
        }
    }
    return true
}
print(isPrime(11))
